import "./About.css";
import React from "react";

function template() {
  const _ele=React.createElement('h1',{'id':'i1'},'Create Element with out jsx');
  return (
    <React.Fragment>
       {_ele}
       <h2>Sachin</h2>
    </React.Fragment>
  );
};

export default template;
