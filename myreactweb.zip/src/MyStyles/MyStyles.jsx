import "./MyStyles.css";
import React from "react";
import Child1 from '../styles/Child1/index'
function template() {
  return (
    <div className="my-styles">
      <h1>MyStyles</h1>
      <Child1 d='true' />
    </div>
  );
};

export default template;
