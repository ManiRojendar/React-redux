import "./Users.css";
import React from "react";
import MyInput from '../InputComponents/MyInput';
import TableComponent from '../tableComponent/index'
function template() {
  const {name,rno,loc,email} =this.state.dataObj;
  const {headers,data,keys,isUpdate} =this.state;
  return (
    <div className="users">
      <h1>Users</h1>
      <MyInput lbl="Name" type="text" id="name" val={name} fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Rno" type="text" id="rno" val={rno} fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Email" type="text" id="email" val={email} fnPrepareData={this.fnPrepareData} />
      <MyInput lbl="Location" type="text" id="loc" val={loc} fnPrepareData={this.fnPrepareData} />
      {
        isUpdate ? <input type='button' value='update' onClick={this.fnUpdate.bind(this)}  />:
       <input type='button' value='register' onClick={this.fnReg.bind(this)} />
      }
      <p>
        {this.state.msg}
      </p>
      <h1>users</h1>
      <TableComponent headers={headers} data={data} keys={keys} fnEdit={this.fnEditData} fnDelete={this.fnDelete} />
    </div>
  );
};

export default template;
