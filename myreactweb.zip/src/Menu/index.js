import Menu from "./Menu";
export default Menu;
