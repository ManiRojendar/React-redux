import "./Menu.css";
import React from "react";
import {HashRouter,Route} from 'react-router-dom';
import Home from '../Home/index';
import About from '../About/index';
import Contact from '../Contact/index';
function template() {
  return (
    <div >
      <HashRouter>
          <div>
              <div className="menu">
              <a href="#/home">Home</a>
              <a href="#/about">About</a>
              <a href="#/contact">Contact</a>
            </div>
            <Route path='/' exact component={Home} />
             <Route path='/home' component={Home} />
             <Route path='/about' component={About} />
             <Route path='/contact' component={Contact} />

          </div>
      </HashRouter>
        
    </div>
  );
};

export default template;
