import "./Contact.css";
import React from "react";

function template() {
  return (
    <div className="contact">
          <div onClick={()=>alert('div1')}>
            Div1
            <div onClick={()=>alert('div2')}>
              Div2
              <div onClick={()=>alert('div3')}>
                Div3

              </div>
            </div>
          </div>
    </div>
  );
};

export default template;
