import React    from "react";
import template from "./Home.jsx";

class Home extends React.Component {
  constructor(){
    super();
    this.state={
      'n':0
    }
    //this.fnUpdateStateCB=this.fnUpdateStateCB.bind(this);
   this.fnInc=this.fnInc.bind(this);
  }

  fnUpdateState(){
      this.fnInc();
      this.fnInc();
      this.fnInc();
  }
  fnInc(){
    this.setState((s)=>{
        return {
          n:s.n+1
        }
    })
    console.log(this.state.n);
  }
  // fnUpdateState(){
  //   this.setState({
  //     n:this.state.n+1
  //   },this.fnUpdateStateCB)
  // }

  // fnUpdateStateCB(){
  //   console.log(this.state.n);
  // }
  render() {
    return template.call(this);
  }
}

export default Home;
