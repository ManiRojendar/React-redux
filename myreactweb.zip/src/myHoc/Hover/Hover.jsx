import "./Hover.css";
import React from "react";

function template() {
  const {count,fnIncCount} =this.props;
  return (
    <div className="hover">
      <h1 onMouseOver={fnIncCount}>He hover me {count} time(s)</h1>
    </div>
  );
};

export default template;
