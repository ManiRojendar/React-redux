import "./MyInput.css";
import React from "react";

function template() {
 const {lbl,type,id,val} =this.props;
  return (
    <p className="my-input">
         <b>{lbl}</b> : <input id={id} value={val} type={type} onChange={this.fnChange.bind(this)} />
    </p>
  );
};

export default template;
