import "./Mask.css";
import React from "react";

function template() {
  return (
    <div >
       <div className="mask"></div>
       <div>
          <h1>R u Sure to delete...</h1>
          <div>
              <input type='button' value="ok" onClick={this.fnConfirm.bind(this,'ok')} />
              <input type='button' value="cancel" onClick={this.fnConfirm.bind(this,'cancel')}/>
          </div>
       </div>
    </div>
  );
};

export default template;
