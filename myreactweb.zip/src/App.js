import React from 'react';
import './App.css';
import Header from './Header/index';
import Footer from './Footer/index';
import ReactDOM from 'react-dom'
import Menu from './Menu/index';
import MenuWithOutHash from './MenuWithOutHash/index';
import Add from './Add/index';
function App() {
  return (
    <div className="App">
        <Header />
        {/* <Menu /> */}
        <MenuWithOutHash />
        <Footer />
       
       {
         ReactDOM.createPortal(<Add />,document.getElementById('add'))
       }


    </div>
  );
}

export default App;
