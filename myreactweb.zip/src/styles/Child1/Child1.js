import React    from "react";
import template from "./Child1.jsx";

class Child1 extends React.Component {
  constructor(){
    super();
    this.myInline={
      color:'red',
      fontSize:'30px'
    }
  }
  render() {
    return template.call(this);
  }
}

export default Child1;
