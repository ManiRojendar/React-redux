import Child1 from "./Child1";
export default Child1;
