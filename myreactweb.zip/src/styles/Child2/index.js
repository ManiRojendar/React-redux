import Child2 from "./Child2";
export default Child2;
