import tableComponent from "./tableComponent";
export default tableComponent;
