import React    from "react";
import template from "./tableComponent.jsx";

class tableComponent extends React.Component {
  constructor(){
    super();
    this.state={
      isShowMask:false,
      id:''
    }
    this.fnConfirm=this.fnConfirm.bind(this);
  }
  render() {
    return template.call(this);
  }
  fnEdit(rowData){
    debugger;
    this.props.fnEdit(rowData);
  }
  fnDelete(rowData){
    this.setState({
      isShowMask:true,
      id:rowData.id
    })
  }
  fnConfirm(msg){
    debugger;
    this.setState({
      isShowMask:false
    })
    if(msg== 'ok'){
      this.props.fnDelete(this.state.id);
    }
  }
}

export default tableComponent;
