import "./MenuWithOutHash.css";
import React from "react";
import {Link,BrowserRouter,Route} from 'react-router-dom';
import Home from '../Home/index';
import About from '../About/index';
import Contact from '../Contact/index';
import MyStyles from '../MyStyles/index';
import Users from '../Users/index';
import HOC from '../HOC/index';
import ReduxBasic from '../reduxBasic/ReduxBasic/index'
function template() {
  return (
    <div className="menu-with-out-hash">
        <BrowserRouter>
            <div>
                <ul>
                    <li><Link to='/home' >Home</Link></li>
                    <li><Link to='/about'>About</Link></li>
                    <li><Link to='/contact'>Contact</Link></li>
                    <li><Link to='/users'>Users</Link></li>
                    <li><Link to='/hoc'>HOC</Link></li>
                    <li><Link to='/styles'>Styles</Link></li>
                    <li><Link to='/redux-basic'>ReduxBasic</Link></li>
                
                </ul>
             <Route path='/' exact component={Home} />
             <Route path='/home' component={Home} />
             <Route path='/about' component={About} />
             <Route path='/contact' component={Contact} />
             <Route path='/users' component={Users} />
             <Route path='/hoc' component={HOC} />
             <Route path='/styles' component={MyStyles} />
             <Route path='/redux-basic' component={ReduxBasic} />
            </div>
        
        </BrowserRouter>
         
    </div>
  );
};

export default template;
