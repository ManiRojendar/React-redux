import React    from "react";
import template from "./C.jsx";
import {connect} from 'react-redux'
class C extends React.Component {
  render() {
    return template.call(this);
  }
}

const mapStateToProps=(state)=>{
   return {
      n:state.playerReducer.name,
      l:state.playerReducer.loc
   }
}

export default connect(mapStateToProps)(C) ;
