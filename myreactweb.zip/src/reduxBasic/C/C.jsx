import "./C.css";
import React from "react";

function template() {
  return (
    <div className="c">
      <h1>C</h1>
      <h2>Name: {this.props.n}</h2>
      <h3>Loc:{this.props.l} </h3>
    </div>
  );
};

export default template;
