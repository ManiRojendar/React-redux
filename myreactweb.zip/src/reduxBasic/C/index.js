import C from "./C";
export default C;
