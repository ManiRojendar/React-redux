import ServerCall from '../../services/ServerCall'
const userAction=(dispatch)=>{
   ServerCall.fnGetReq('https://jsonplaceholder.typicode.com/users')
   .then((res)=>{
      dispatch({
          'type':'USERS',
         'payload':res.data
      })
   })
   .catch((res)=>{
    dispatch({
        'type':'USERS',
       'payload':[]
    })
   })
}

export default userAction;