import "./ReduxBasic.css";
import React from "react";
import A from '../A/index';
import B from '../B/index';
import C from '../C/index';
import Users from '../Users/index';
import Posts from '../Posts/index';
function template() {
  return (
    <div className="redux-basic">
      <h1>ReduxBasic</h1>
       <A/>
       <B/>
       <C/>
       <Users />
       <Posts />

    </div>
  );
};

export default template;
