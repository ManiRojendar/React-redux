import ReduxBasic from "./ReduxBasic";
export default ReduxBasic;
