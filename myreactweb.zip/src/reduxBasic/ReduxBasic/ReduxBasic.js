import React    from "react";
import template from "./ReduxBasic.jsx";

class ReduxBasic extends React.Component {
  render() {
    return template.call(this);
  }
}

export default ReduxBasic;
