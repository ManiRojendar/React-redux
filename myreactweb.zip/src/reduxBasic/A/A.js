import React    from "react";
import template from "./A.jsx";
import {connect} from 'react-redux'
class A extends React.Component {
  render() {
    return template.call(this);
  }
  fnGetData(){
    let name=this.refs.nameRef.value;
    this.props.dispatch({
      type:'NAME',
      payload:name
    })
  }
}
const mapDispatchToProps=(dispatch)=>{
   return {
    dispatch:dispatch
   }
}
export default connect(null,mapDispatchToProps)(A)
