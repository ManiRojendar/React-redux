import "./A.css";
import React from "react";

function template() {
  return (
    <div className="a">
      <h1>A</h1>
      <input ref="nameRef" />
      <input type='button' value="set data" onClick={this.fnGetData.bind(this)} />
    </div>
  );
};

export default template;
