import React    from "react";
import template from "./Users.jsx";
import userAction from '../actions/usersAction';
import {connect} from 'react-redux'
class Users extends React.Component {
  fnGetUsers(){
    debugger;
    userAction(this.props.dispatch);
  }
  render() {
    return template.call(this);
  }
}
const mdp=(dispatch)=>{
  return {
    dispatch:dispatch
  }
}
export default connect(null,mdp)(Users);
