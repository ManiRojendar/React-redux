import playerReducer from './playerReducer';
import actionReducer from './actionReducer'
import {combineReducers} from 'redux'

const rootReducer=combineReducers({playerReducer,actionReducer});

export default rootReducer;