import { initActionData } from '../utils/initData'
const actionReducer = (state = initActionData, action) => {
    switch (action.type) {
        case "USERS":
            state={
                ...state,
                users:action.payload
            }
            break;
        case "POSTS":
                state={
                    ...state,
                    posts:action.payload
                }
            break;
    }
    return state;
}

export default actionReducer;