import {initVal} from '../utils/initData';

const playerReducer=(state=initVal,dispatchData)=>{
    switch(dispatchData.type){
        case 'NAME':
            state={
                ...state,
                name:dispatchData.payload
            }
            break;
        case 'LOC':
                state={
                    ...state,
                    loc:dispatchData.payload
                }
             break;
    }
    return state;
}

export default playerReducer;