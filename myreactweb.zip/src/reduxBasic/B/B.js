import React from "react";
import template from "./B.jsx";
import store from '../store';
class B extends React.Component {
  constructor() {
    super();
    this.locRef = React.createRef();
  }
  render() {
    return template.call(this);
  }
  fnGetData() {
    let loc = this.locRef.current.value;
    store.dispatch({
      type: 'LOC',
      payload: loc
    })
  }
}

export default B;
