import "./B.css";
import React from "react";

function template() {
  return (
    <div className="b">
      <h1>B</h1>
      <input ref={this.locRef} />
      <input type='button' value="set data" onClick={this.fnGetData.bind(this)} />
    
    </div>
  );
};

export default template;
