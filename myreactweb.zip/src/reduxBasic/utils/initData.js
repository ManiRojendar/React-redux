export const initVal={
    name:'',
    loc:''
}

export const initActionData={
    users:[],
    posts:[]
}